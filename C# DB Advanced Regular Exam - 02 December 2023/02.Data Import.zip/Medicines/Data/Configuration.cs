﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-TG50FJH\SQLEXPRESS;Database=Medicines;Integrated Security=True;Encrypt=False";
    }
}
