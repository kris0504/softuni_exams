﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastre.DataProcessor.ExportDtos
{
    public class ExportOwnerDto
    {
        public string LastName { get; set; }
        public string MaritalStatus { get; set; }
    }
}
