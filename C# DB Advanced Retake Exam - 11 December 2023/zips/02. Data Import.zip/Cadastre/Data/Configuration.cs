﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-TG50FJH\SQLEXPRESS;Database=Cadastre;Integrated Security=True;Encrypt=False";
    }
}
